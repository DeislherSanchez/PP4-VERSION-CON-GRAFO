/*****Datos administrativos************************
 * Nombre del archivo: AreaDibujoGrafo.cpp
 * Tipo de archivo: Código fuente
 * Proyecto: Gestión de Tareas y Proyectos
 * Autor: [Tu Nombre]
 * Empresa: Tecnológico de Costa Rica
 *****Descripción**********************************
 * Implementación de la clase AreaDibujoGrafo para
 * la visualización gráfica del grafo de tareas.
 *****Versión**************************************
 * 1.0 | [Fecha y hora] | [Tu Nombre]
 **************************************************/

#include "AreaDibujoGrafo.hpp"

AreaDibujoGrafo::AreaDibujoGrafo(GrafoDeTareas* pGrafo) : pGrafo(pGrafo) {}

AreaDibujoGrafo::~AreaDibujoGrafo() {}

bool AreaDibujoGrafo::on_draw(const Cairo::RefPtr<Cairo::Context>& cr) {
    Gtk::Allocation allocation = get_allocation();
    const int width = allocation.get_width();
    const int height = allocation.get_height();

    // Fondo blanco
    cr->set_source_rgb(1.0, 1.0, 1.0);
    cr->paint();

    // Dibujar el grafo
    dibujarGrafo(cr);

    return true;
}

void AreaDibujoGrafo::dibujarGrafo(const Cairo::RefPtr<Cairo::Context>& cr) {
    if (pGrafo == nullptr) return;

    Gtk::Allocation allocation = get_allocation();
    const int width = allocation.get_width();
    const int height = allocation.get_height();

    int cantidadNodos = pGrafo->getCantidadNodos();
    if (cantidadNodos == 0) return;

    std::vector<Gdk::Point> posicionesNodos(cantidadNodos);

    double angle_increment = 2 * M_PI / cantidadNodos;
    int radio = std::min(width, height) / 3;
    int centroX = width / 2;
    int centroY = height / 2;

    for (int i = 0; i < cantidadNodos; ++i) {
        double angle = i * angle_increment;
        int x = centroX + radio * cos(angle);
        int y = centroY + radio * sin(angle);
        posicionesNodos[i] = Gdk::Point(x, y);
    }

    // Dibujar aristas (dependencias)
    cr->set_source_rgb(0.0, 0.0, 0.0); // Color negro para las aristas
    for (int i = 0; i < cantidadNodos; ++i) {
        Nodo* nodoOrigen = pGrafo->obtenerNodo(i);
        Nodo** dependencias = nodoOrigen->getDependencias();
        int cantidadDependencias = nodoOrigen->getCantidadDependencias();

        for (int j = 0; j < cantidadDependencias; ++j) {
            Nodo* nodoDestino = dependencias[j];
            int indiceDestino = pGrafo->obtenerIndiceNodo(nodoDestino);

            if (indiceDestino != -1) {
                cr->move_to(posicionesNodos[i].get_x(), posicionesNodos[i].get_y());
                cr->line_to(posicionesNodos[indiceDestino].get_x(), posicionesNodos[indiceDestino].get_y());
                cr->stroke();
            }
        }
    }

    // Dibujar nodos
    for (int i = 0; i < cantidadNodos; ++i) {
        // Nodo
        cr->set_source_rgb(0.2, 0.6, 0.8); // Color azul para los nodos
        cr->arc(posicionesNodos[i].get_x(), posicionesNodos[i].get_y(), 20, 0, 2 * M_PI);
        cr->fill_preserve();
        cr->set_source_rgb(0.0, 0.0, 0.0); // Borde negro
        cr->stroke();

        // Etiqueta
        Tarea* tarea = pGrafo->obtenerNodo(i)->getTarea();
        cr->set_source_rgb(0.0, 0.0, 0.0);
        cr->select_font_face("Sans", Cairo::FONT_SLANT_NORMAL, Cairo::FONT_WEIGHT_BOLD);
        cr->set_font_size(12);
        Cairo::TextExtents extents;
        std::string nombreTarea = tarea->getNombre().mostrarCadena();
        cr->get_text_extents(nombreTarea, extents);
        cr->move_to(posicionesNodos[i].get_x() - extents.width / 2, posicionesNodos[i].get_y() + extents.height / 2);
        cr->show_text(nombreTarea);
    }
}
