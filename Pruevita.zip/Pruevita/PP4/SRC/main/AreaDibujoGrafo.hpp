/*****Datos administrativos************************
 * Nombre del archivo: AreaDibujoGrafo.hpp
 * Tipo de archivo: Encabezado
 * Proyecto: Gestión de Tareas y Proyectos
 * Autor: [Tu Nombre]
 * Empresa: Tecnológico de Costa Rica
 *****Descripción**********************************
 * Clase que implementa un área de dibujo para la
 * visualización gráfica del grafo de tareas.
 *****Versión**************************************
 * 1.0 | [Fecha y hora] | [Tu Nombre]
 **************************************************/

#ifndef AREA_DIBUJO_GRAFO_HPP
#define AREA_DIBUJO_GRAFO_HPP

#include <gtkmm.h>
#include <vector>
#include <cmath>
#include "GrafoDeTareas.hpp"

class AreaDibujoGrafo : public Gtk::DrawingArea {
public:
    AreaDibujoGrafo(GrafoDeTareas* pGrafo);
    virtual ~AreaDibujoGrafo();

protected:
    bool on_draw(const Cairo::RefPtr<Cairo::Context>& cr) override;

private:
    GrafoDeTareas* pGrafo;

    void dibujarGrafo(const Cairo::RefPtr<Cairo::Context>& cr);
};

#endif // AREA_DIBUJO_GRAFO_HPP
