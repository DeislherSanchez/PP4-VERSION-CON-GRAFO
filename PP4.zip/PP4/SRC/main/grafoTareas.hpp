#include "String.hpp"
#include <iostream>
class GrafoDeTareas {
private:
    Tarea** tareas;
    int** matrizAdyacencia;
    int numTareas;

public:
    GrafoDeTareas() : tareas(nullptr), matrizAdyacencia(nullptr), numTareas(0) {}

    ~GrafoDeTareas() {
        for (int i = 0; i < numTareas; i++) {
            delete tareas[i];
        }
        delete[] tareas;
        for (int i = 0; i < numTareas; i++) {
            delete[] matrizAdyacencia[i];
        }
        delete[] matrizAdyacencia;
    }

    void agregarTarea(int id, const String& nombre, int duracion) {
        Tarea** nuevasTareas = new Tarea*[numTareas + 1];
        for (int i = 0; i < numTareas; i++) {
            nuevasTareas[i] = tareas[i];
        }
        nuevasTareas[numTareas] = new Tarea(id, nombre, duracion);
        delete[] tareas;
        tareas = nuevasTareas;
        numTareas++;

        redimensionarMatrizAdyacencia();
    }

    void agregarDependencia(int idOrigen, int idDestino, int duracionDependencia) {
        if (idOrigen < numTareas && idDestino < numTareas) {
            matrizAdyacencia[idOrigen][idDestino] = duracionDependencia;
        }
    }

    void listarTareas() const {
        for (int i = 0; i < numTareas; i++) {
            char* nombre = tareas[i]->getNombre().mostrarCadena();
            std::cout << "Tarea ID: " << tareas[i]->getId() 
                      << ", Nombre: " << nombre 
                      << ", Duración: " << tareas[i]->getDuracion() 
                      << '\n';
            delete[] nombre;
        }
    }
    
    void eliminarNodo(int id) {
        if (id < 0 || id >= numTareas) {
            std::cerr << "Error: ID fuera de rango.\n";
            return;
        }

        // Eliminar la tarea del arreglo de tareas
        Tarea** nuevasTareas = new Tarea*[numTareas - 1];
        int index = 0;

        for (int i = 0; i < numTareas; i++) {
            if (i != id) {
                nuevasTareas[index++] = tareas[i];
            } else {
                delete tareas[i]; // Liberar memoria de la tarea eliminada
            }
        }
        delete[] tareas; // Liberar arreglo original
        tareas = nuevasTareas;

        // Ajustar la matriz de adyacencia
        int** nuevaMatriz = new int*[numTareas - 1];
        for (int i = 0, newRow = 0; i < numTareas; i++) {
            if (i == id) continue; // Saltar fila eliminada
            nuevaMatriz[newRow] = new int[numTareas - 1];
            for (int j = 0, newCol = 0; j < numTareas; j++) {
                if (j != id) {
                    nuevaMatriz[newRow][newCol++] = matrizAdyacencia[i][j];
                }
            }
            newRow++;
        }

        // Liberar la memoria de la matriz original
        for (int i = 0; i < numTareas; i++) {
            delete[] matrizAdyacencia[i];
        }
        delete[] matrizAdyacencia;

        matrizAdyacencia = nuevaMatriz;
        numTareas--; // Disminuir el número de tareas
    }

private:
    void redimensionarMatrizAdyacencia() {
        int** nuevaMatriz = new int*[numTareas];
        for (int i = 0; i < numTareas; i++) {
            nuevaMatriz[i] = new int[numTareas];
            for (int j = 0; j < numTareas; j++) {
                nuevaMatriz[i][j] = (i < numTareas - 1 && j < numTareas - 1) ? matrizAdyacencia[i][j] : 0;
            }
        }

        for (int i = 0; i < numTareas - 1; i++) {
            delete[] matrizAdyacencia[i];
        }
        delete[] matrizAdyacencia;
        matrizAdyacencia = nuevaMatriz;
    }
};
