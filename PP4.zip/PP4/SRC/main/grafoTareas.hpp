#include "String.hpp"
#include <iostream>
class GrafoDeTareas {
private:
    Tarea** tareas;
    int** matrizAdyacencia;
    int numTareas;

public:
    GrafoDeTareas() : tareas(nullptr), matrizAdyacencia(nullptr), numTareas(0) {}

    ~GrafoDeTareas() {
        for (int i = 0; i < numTareas; i++) {
            delete tareas[i];
        }
        delete[] tareas;
        for (int i = 0; i < numTareas; i++) {
            delete[] matrizAdyacencia[i];
        }
        delete[] matrizAdyacencia;
    }

    void agregarTarea(int id, const String& nombre, int duracion) {
        Tarea** nuevasTareas = new Tarea*[numTareas + 1];
        for (int i = 0; i < numTareas; i++) {
            nuevasTareas[i] = tareas[i];
        }
        nuevasTareas[numTareas] = new Tarea(id, nombre, duracion);
        delete[] tareas;
        tareas = nuevasTareas;
        numTareas++;

        redimensionarMatrizAdyacencia();
    }

    void agregarDependencia(int idOrigen, int idDestino, int duracionDependencia) {
        if (idOrigen < numTareas && idDestino < numTareas) {
            matrizAdyacencia[idOrigen][idDestino] = duracionDependencia;
        }
    }

    void listarTareas() const {
        for (int i = 0; i < numTareas; i++) {
            char* nombre = tareas[i]->getNombre().mostrarCadena();
            std::cout << "Tarea ID: " << tareas[i]->getId() 
                      << ", Nombre: " << nombre 
                      << ", Duración: " << tareas[i]->getDuracion() 
                      << '\n';
            delete[] nombre;
        }
    }

private:
    void redimensionarMatrizAdyacencia() {
        int** nuevaMatriz = new int*[numTareas];
        for (int i = 0; i < numTareas; i++) {
            nuevaMatriz[i] = new int[numTareas];
            for (int j = 0; j < numTareas; j++) {
                nuevaMatriz[i][j] = (i < numTareas - 1 && j < numTareas - 1) ? matrizAdyacencia[i][j] : 0;
            }
        }

        for (int i = 0; i < numTareas - 1; i++) {
            delete[] matrizAdyacencia[i];
        }
        delete[] matrizAdyacencia;
        matrizAdyacencia = nuevaMatriz;
    }
};
